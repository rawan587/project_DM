import pandas as pd
from sklearn.feature_selection import SelectKBest, f_regression
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler

# ============ Step 1: Load data and split X / y ============
df = pd.read_csv("student_cleaned_encoded.csv")

print("Shape:", df.shape)
print("Missing values:", df.isnull().sum().sum())

X = df.drop(columns=["Exam_Score"])
y = df["Exam_Score"]

# Train-Test Split
X_train, X_test, y_train, y_test = train_test_split(
    X, y,
    test_size=0.2,
    random_state=42
)

print("Training data shape:", X_train.shape)
print("Testing data shape:", X_test.shape)

#---------------------------------------------
print("X shape:", X.shape)
print("y shape:", y.shape)

# ============ Step 2: Feature Selection ============
# 2.a Correlation with the target
corr = df.corr()["Exam_Score"].drop("Exam_Score").abs().sort_values(ascending=False)
print("\n--- |Correlation| with Exam_Score ---")
print(corr)

# Feature Selection using Training Data Only
selector = SelectKBest(score_func=f_regression, k="all")
selector.fit(X_train, y_train)

scores = pd.DataFrame({
    "Feature": X_train.columns,
    "F_score": selector.scores_,
    "p_value": selector.pvalues_
}).sort_values("F_score", ascending=False)

scores_display = scores.copy()
scores_display["F_score"] = scores_display["F_score"].round(2)
scores_display["Decision"] = scores_display["p_value"].apply(
    lambda p: "Keep" if p <= 0.05 else "Drop"
)
scores_display["p_value"] = scores_display["p_value"].apply(
    lambda p: f"{p*100:.2f}%"
)

print("\nFeature Selection Results:")
print(scores_display.to_string(index=False))

# Drop insignificant features from both datasets
features_to_drop = scores[scores["p_value"] > 0.05]["Feature"].tolist()

X_train = X_train.drop(columns=features_to_drop)
X_test = X_test.drop(columns=features_to_drop)

print("\nDropped features:", features_to_drop)
print("X_train shape after selection:", X_train.shape)
print("X_test shape after selection:", X_test.shape)

#----------------------------------
# ============ Step 3: Feature Scaling ============

scaler = StandardScaler()

X_train_scaled = pd.DataFrame(
    scaler.fit_transform(X_train),
    columns=X_train.columns,
    index=X_train.index
)

X_test_scaled = pd.DataFrame(
    scaler.transform(X_test),
    columns=X_test.columns,
    index=X_test.index
)

print("\n--- Feature Scaling Results ---")
print("X_train_scaled shape:", X_train_scaled.shape)
print("X_test_scaled shape:", X_test_scaled.shape)



print("\nBefore Scaling:")
print(X_train["Hours_Studied"].head())

print("\nAfter Scaling:")
print(X_train_scaled["Hours_Studied"].head())
#---------------------------------------------------
# ============ Step 3: Model Training ============

from sklearn.linear_model import LinearRegression

# Create the model
model = LinearRegression()

# Train the model
model.fit(X_train_scaled, y_train)

print("\nModel Training Completed Successfully!")

# ============ Step 4: Prediction ============

y_pred = model.predict(X_test_scaled)

print("\nFirst 10 Predictions:")
for i, prediction in enumerate(y_pred[:10], start=1):
    print(f"Student {i}: {prediction:.2f}")

# ============ Step 5: Model Evaluation ============

from sklearn.metrics import mean_squared_error, r2_score
import numpy as np

# Calculate RMSE
rmse = np.sqrt(mean_squared_error(y_test, y_pred))

# Calculate R2 Score
r2 = r2_score(y_test, y_pred)

print("\n--- Model Evaluation ---")
print(f"RMSE     : {rmse:.2f}")
print(f"R2 Score : {r2:.4f}")


# ============ Step 6: Supporting Visualizations ============
import os
import matplotlib.pyplot as plt

os.makedirs("visualization", exist_ok=True)

# 8.a Feature importance
coef = pd.Series(model.coef_, index=X_train_scaled.columns).sort_values()
plt.figure(figsize=(8, 6))
coef.plot(kind="barh", color="steelblue")
plt.title("Feature Importance (Linear Regression Coefficients)")
plt.xlabel("Coefficient")
plt.tight_layout()
plt.savefig("visualization/feature_importance.png", dpi=300)
plt.close()

# 8.b Residuals plot
residuals = y_test - y_pred
plt.figure(figsize=(8, 6))
plt.scatter(y_pred, residuals, alpha=0.6)
plt.axhline(0, color="red", linestyle="--")
plt.title("Residuals Plot")
plt.xlabel("Predicted Scores")
plt.ylabel("Residuals (Actual - Predicted)")
plt.grid(True)
plt.tight_layout()
plt.savefig("visualization/residuals_plot.png", dpi=300)
plt.close()

print("Saved 2 supporting visualizations in /visualization")

# ============ Step 6: Actual vs Predicted Visualization ============

import matplotlib.pyplot as plt

# Create scatter plot
plt.figure(figsize=(8, 6))

plt.scatter(y_test, y_pred, alpha=0.6, label="Predicted Scores")

# Perfect prediction line
min_score = min(y_test.min(), y_pred.min())
max_score = max(y_test.max(), y_pred.max())

plt.plot(
    [min_score, max_score],
    [min_score, max_score],
    color="red",
    linestyle="--",
    label="Perfect Prediction"
)

# Add titles and labels
plt.title("Actual vs Predicted Scores")
plt.xlabel("Actual Scores")
plt.ylabel("Predicted Scores")

plt.legend()
plt.grid(True)
plt.tight_layout()
#plt.savefig("actual_vs_predicted.png", dpi=300)
plt.show()

# ============ Step 7: Prediction for New Students ============

new_students = pd.DataFrame({
    "Hours_Studied":              [8,  20, 35],
    "Attendance":                 [60, 80, 98],
    "Parental_Involvement":       [0,  1,  2],
    "Access_to_Resources":        [0,  1,  2],
    "Extracurricular_Activities": [0,  1,  1],
    "Previous_Scores":            [55, 75, 95],
    "Motivation_Level":           [0,  1,  2],
    "Internet_Access":            [0,  1,  1],
    "Tutoring_Sessions":          [0,  1,  3],
    "Family_Income":              [0,  1,  2],
    "Teacher_Quality":            [0,  1,  2],
    "Peer_Influence":             [0,  1,  2],
    "Physical_Activity":          [1,  3,  5],
    "Learning_Disabilities":      [1,  0,  0],
    "Parental_Education_Level":   [0,  1,  2],
    "Distance_from_Home":         [2,  1,  0],
})

# same columns and same order as the training data
new_students = new_students[X_train.columns]

# use the SAME scaler (transform only, no fit)
new_students_scaled = pd.DataFrame(
    scaler.transform(new_students),
    columns=new_students.columns
)

new_predictions = model.predict(new_students_scaled)

result = new_students.copy()
result.insert(0, "Student", ["Weak", "Average", "Strong"])
result["Predicted_Exam_Score"] = new_predictions.round(2)

print("\n--- Predictions for New Students ---")
print(result[["Student", "Hours_Studied", "Attendance", "Previous_Scores", "Predicted_Exam_Score"]].to_string(index=False))

result.to_csv("new_students_predictions.csv", index=False)
print("\nSaved new_students_predictions.csv")