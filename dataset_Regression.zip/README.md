# Part 2 - Student Performance Prediction (Regression)

**Person 4: Regression Model + Evaluation**

## Goal
Predict a student's final `Exam_Score` from study habits, family and school factors.

## Input
`student_cleaned_encoded.csv` (output of Person 3's cleaning): 6607 rows, 19 input columns + target `Exam_Score`. All columns are numeric (already encoded).

## Steps

1. **Load data and split X / y.** `y = Exam_Score`, `X` = all other columns.
2. **Train/Test split (80/20, random_state=42).** 5285 training rows, 1322 test rows. The split is done *before* feature selection and scaling to avoid data leakage.
3. **Feature selection (SelectKBest, f_regression, on training data only).** Features with p-value > 0.05 were dropped: `Sleep_Hours`, `School_Type`, `Gender`. 16 features remain.
4. **Feature scaling (StandardScaler).** Fitted on the training set only, then applied (`transform`) to the test set and to new students.
5. **Model: Linear Regression.** Simple, easy to interpret, and accurate enough for this dataset.
6. **Evaluation on the test set.**
   - RMSE = **1.81** (average prediction error is about 1.8 points)
   - R² = **0.7694** (the model explains about 77% of the variance in exam scores)
7. **Prediction for new students.** Three hypothetical students (Weak / Average / Strong) were scaled with the same scaler and passed to the model.

   | Student | Hours_Studied | Attendance | Previous_Scores | Predicted score |
   |---|---|---|---|---|
   | Weak | 8 | 60 | 55 | 50.13 |
   | Average | 20 | 80 | 75 | 67.09 |
   | Strong | 35 | 98 | 95 | 82.72 |

   Predictions increase with study hours, attendance and previous scores, as expected.

## Handle imbalance
Not applicable. Class imbalance concerns classification problems; `Exam_Score` is a continuous target.

## Visualizations (folder `visualization/`)
- `actual_vs_predicted.png`: actual vs predicted scores on the test set; points close to the red dashed line mean good predictions.
- `feature_importance.png`: model coefficients on scaled features. `Attendance` and `Hours_Studied` are the strongest positive factors; `Learning_Disabilities` and `Distance_from_Home` lower the score.
- `residuals_plot.png`: most errors are close to 0; a handful of outliers (large positive residuals) raise the RMSE.

## Files
| File | Description |
|---|---|
| `student_regression_model.py` | Full code (selection, scaling, training, evaluation, plots, new-student prediction) |
| `student_cleaned_encoded.csv` | Cleaned and encoded data from Person 3 |
| `new_students_predictions.csv` | Predictions for the 3 new students |
| `visualization/` | The plots listed above |

## How to run
```
pip install pandas numpy scikit-learn matplotlib seaborn
python student_regression_model.py
```
Keep the CSV in the same folder as the script.
